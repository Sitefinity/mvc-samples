﻿(function () {
    $(".menu .dropdown").dropdown();
})();